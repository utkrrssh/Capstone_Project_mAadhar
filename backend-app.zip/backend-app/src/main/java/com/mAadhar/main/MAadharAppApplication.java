package com.mAadhar.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MAadharAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MAadharAppApplication.class, args);
	}

}
